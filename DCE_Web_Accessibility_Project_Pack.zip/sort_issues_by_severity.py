"""Sort recorded audit findings by severity. This does not scan websites or certify WCAG compliance."""
import csv, sys
ORDER={"Critical":0,"High":1,"Medium":2,"Low":3,"Informational":4,"Unrated":5,"":6}
def main():
    if len(sys.argv)!=2:
        print("Usage: python sort_issues_by_severity.py audit.csv"); return
    with open(sys.argv[1],newline="",encoding="utf-8-sig") as f:
        rows=list(csv.DictReader(f))
    rows.sort(key=lambda r:(ORDER.get(r.get("Severity","Unrated"),5),r.get("Page",""),r.get("Check ID","")))
    output="audit_sorted_by_severity.csv"
    fields=list(rows[0].keys()) if rows else []
    with open(output,"w",newline="",encoding="utf-8") as f:
        writer=csv.DictWriter(f,fieldnames=fields)
        if fields: writer.writeheader(); writer.writerows(rows)
    print(f"Sorted {len(rows)} rows into {output}")
if __name__=="__main__": main()
