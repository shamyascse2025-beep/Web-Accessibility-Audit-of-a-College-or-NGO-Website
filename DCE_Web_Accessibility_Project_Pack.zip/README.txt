DCE WEB ACCESSIBILITY AUDIT PROJECT PACK

Included:
- DCE_Web_Accessibility_Audit_Report_Working_Draft.docx
- DCE_Accessibility_Audit_Tracker.xlsx
- DCE_Accessibility_Audit_6_Slide_Presentation.pptx
- sort_issues_by_severity.py

Important: This is a research-backed working pack, not a completed conformance certification.
The tracker begins with Not tested. Run WAVE and Lighthouse on all five pages and complete
manual keyboard, focus, zoom/reflow, image-alt and form-label checks. Save screenshots.
Do not describe an item as a confirmed failure until verified.

Target: https://dce.edu.in/
Standard: https://www.w3.org/TR/WCAG/
WAVE: https://wave.webaim.org/
